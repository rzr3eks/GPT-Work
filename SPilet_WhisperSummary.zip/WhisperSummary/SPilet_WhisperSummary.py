import openai

openai.api_key = "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"
model_id = 'whisper-1'

media_file_path = 'whisp.wav'
media_file = open(media_file_path, 'rb')

transcription = openai.audio.transcriptions.create(
    model="whisper-1",
    file=media_file,
)
#print(transcription.text)

from openai import OpenAI
client = OpenAI(api_key = "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")

completion = client.chat.completions.create(
  model="gpt-3.5-turbo",
  messages=[
    {
      "role": "user",
      "content": f"Summarize the following text: {transcription.text}"
    }
  ],
  
)
# Extract the response
print(completion.choices[0].message.content)


